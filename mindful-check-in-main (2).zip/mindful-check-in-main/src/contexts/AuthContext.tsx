import { createContext, useContext, useState, ReactNode } from "react";

interface User {
  name: string;
  email: string;
  isGuest: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => void;
  signup: (name: string, email: string, password: string) => void;
  guestLogin: () => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem("mindcheck_user");
    return saved ? JSON.parse(saved) : null;
  });

  const persist = (u: User) => {
    setUser(u);
    localStorage.setItem("mindcheck_user", JSON.stringify(u));
  };

  const login = (email: string, _password: string) => {
    persist({ name: email.split("@")[0], email, isGuest: false });
  };

  const signup = (name: string, email: string, _password: string) => {
    persist({ name, email, isGuest: false });
  };

  const guestLogin = () => {
    persist({ name: "Guest", email: "guest@mindcheck.app", isGuest: true });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("mindcheck_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, guestLogin, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
