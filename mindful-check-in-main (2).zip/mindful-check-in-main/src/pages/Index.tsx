import { Link } from "react-router-dom";
import { Heart, BarChart3, MessageCircleHeart, Shield } from "lucide-react";

const features = [
  {
    icon: MessageCircleHeart,
    title: "AI-Powered Check-Ins",
    desc: "Share how you feel and receive personalized, compassionate guidance.",
  },
  {
    icon: BarChart3,
    title: "Mood Tracking",
    desc: "Visualize your emotional journey over time with beautiful charts.",
  },
  {
    icon: Shield,
    title: "Private & Safe",
    desc: "Your mental health data stays on your device. No judgment, ever.",
  },
];

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="gradient-hero px-6 pb-20 pt-16 text-center">
        <div className="mx-auto max-w-3xl">
          <div className="mb-6 inline-flex animate-float items-center gap-2 rounded-full bg-secondary px-4 py-2 text-sm font-medium text-secondary-foreground">
            <Heart className="h-4 w-4" />
            Your mental wellness companion
          </div>
          <h1 className="mb-6 font-display text-5xl leading-tight text-foreground md:text-6xl">
            How are you feeling{" "}
            <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              today?
            </span>
          </h1>
          <p className="mb-10 text-lg leading-relaxed text-muted-foreground">
            MindCheck is your gentle, AI-powered mental health companion.
            Track your mood, receive thoughtful advice, and nurture your
            emotional well-being — one check-in at a time.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              to="/checkin"
              className="gradient-calm rounded-lg px-8 py-3 text-base font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-105"
            >
              Start Check-In
            </Link>
            <Link
              to="/auth"
              className="rounded-lg border bg-background px-8 py-3 text-base font-semibold text-foreground transition-colors hover:bg-muted"
            >
              Create Account
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-6 py-20">
        <div className="mx-auto max-w-5xl">
          <h2 className="mb-12 text-center font-display text-3xl text-foreground">
            A kinder way to care for your mind
          </h2>
          <div className="grid gap-8 md:grid-cols-3">
            {features.map((f, i) => (
              <div
                key={f.title}
                className="rounded-xl border bg-card p-8 transition-shadow hover:shadow-glow"
                style={{ animationDelay: `${i * 0.15}s` }}
              >
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <f.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 font-display text-xl text-card-foreground">
                  {f.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {f.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="gradient-warm px-6 py-16 text-center">
        <div className="mx-auto max-w-2xl">
          <h2 className="mb-4 font-display text-3xl text-accent-foreground">
            Your feelings matter
          </h2>
          <p className="mb-8 text-accent-foreground/70">
            No sign-up required. Start as a guest and begin your journey now.
          </p>
          <Link
            to="/checkin"
            className="inline-block gradient-calm rounded-lg px-8 py-3 font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-105"
          >
            Try It Free
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t px-6 py-8 text-center text-sm text-muted-foreground">
        © 2026 MindCheck. Built with care for your well-being.
      </footer>
    </div>
  );
};

export default Index;
