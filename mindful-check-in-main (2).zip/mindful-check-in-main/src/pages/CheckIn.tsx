import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import MoodSelector from "@/components/MoodSelector";
import ChatBot from "@/components/ChatBot";
import MoodChart from "@/components/MoodChart";

export interface MoodEntry {
  mood: string;
  score: number;
  note: string;
  date: string;
  advice: string;
}

const CheckIn = () => {
  const { user, guestLogin } = useAuth();
  const navigate = useNavigate();
  const [entries, setEntries] = useState<MoodEntry[]>(() => {
    const saved = localStorage.getItem("mindcheck_entries");
    return saved ? JSON.parse(saved) : [];
  });

  const addEntry = (entry: MoodEntry) => {
    const updated = [entry, ...entries];
    setEntries(updated);
    localStorage.setItem("mindcheck_entries", JSON.stringify(updated));
  };

  // Auto guest login if not authenticated
  if (!user) {
    guestLogin();
    return null;
  }

  return (
    <div className="mx-auto min-h-screen max-w-5xl px-6 py-10">
      <div className="mb-8 text-center">
        <h1 className="font-display text-4xl text-foreground">
          Mental Health Check-In
        </h1>
        <p className="mt-2 text-muted-foreground">
          Hi {user.name}! How are you feeling right now?
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <div className="space-y-8">
          <MoodSelector onSubmit={addEntry} />
          <ChatBot entries={entries} />
        </div>
        <div>
          <MoodChart entries={entries} />
        </div>
      </div>
    </div>
  );
};

export default CheckIn;
