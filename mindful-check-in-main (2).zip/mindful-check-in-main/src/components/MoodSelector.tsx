import { useState } from "react";
import type { MoodEntry } from "@/pages/CheckIn";

const moods = [
  { emoji: "😊", label: "Happy", score: 5 },
  { emoji: "😌", label: "Calm", score: 4 },
  { emoji: "😐", label: "Neutral", score: 3 },
  { emoji: "😟", label: "Anxious", score: 2 },
  { emoji: "😢", label: "Sad", score: 1 },
];

const adviceMap: Record<string, string[]> = {
  Happy: [
    "Wonderful! Keep nurturing what brings you joy today.",
    "Your positive energy is powerful. Consider sharing it with someone.",
    "Great mood! This is a perfect time for creative activities.",
  ],
  Calm: [
    "Peace is a gift. Try to carry this stillness through your day.",
    "Beautiful state of mind. Consider a short meditation to deepen it.",
    "Calmness is strength. Take a moment to appreciate this feeling.",
  ],
  Neutral: [
    "A balanced state can be a good foundation. What small thing could brighten your day?",
    "Sometimes neutral is perfectly okay. Be gentle with yourself.",
    "Consider a short walk or a cup of tea to gently lift your spirits.",
  ],
  Anxious: [
    "Take a deep breath. Try the 4-7-8 technique: breathe in 4s, hold 7s, out 8s.",
    "Anxiety is temporary. Ground yourself: name 5 things you can see right now.",
    "You're not alone. Consider reaching out to someone you trust.",
  ],
  Sad: [
    "It's okay to feel sad. Allow yourself this feeling without judgment.",
    "Sadness often carries important messages. Be compassionate with yourself.",
    "Consider doing one small act of self-care today. You deserve kindness.",
  ],
};

const getAdvice = (mood: string) => {
  const list = adviceMap[mood] || adviceMap.Neutral;
  return list[Math.floor(Math.random() * list.length)];
};

interface Props {
  onSubmit: (entry: MoodEntry) => void;
}

const MoodSelector = ({ onSubmit }: Props) => {
  const [selected, setSelected] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [lastAdvice, setLastAdvice] = useState("");

  const handleSubmit = () => {
    if (selected === null) return;
    const mood = moods[selected];
    const advice = getAdvice(mood.label);
    setLastAdvice(advice);
    onSubmit({
      mood: mood.label,
      score: mood.score,
      note,
      date: new Date().toISOString(),
      advice,
    });
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setSelected(null);
      setNote("");
    }, 4000);
  };

  return (
    <div className="rounded-xl border bg-card p-6">
      <h2 className="mb-4 font-display text-xl text-card-foreground">
        How are you feeling?
      </h2>
      <div className="mb-4 flex justify-between gap-2">
        {moods.map((m, i) => (
          <button
            key={m.label}
            onClick={() => setSelected(i)}
            className={`flex flex-1 flex-col items-center gap-1 rounded-lg border p-3 transition-all ${
              selected === i
                ? "border-primary bg-primary/10 shadow-glow"
                : "border-border hover:border-primary/40"
            }`}
          >
            <span className="text-2xl">{m.emoji}</span>
            <span className="text-xs text-muted-foreground">{m.label}</span>
          </button>
        ))}
      </div>
      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Add a note about how you're feeling (optional)..."
        className="mb-4 w-full rounded-lg border bg-background p-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        rows={3}
      />
      <button
        onClick={handleSubmit}
        disabled={selected === null}
        className="w-full gradient-calm rounded-lg py-3 font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100"
      >
        Submit Check-In
      </button>

      {submitted && lastAdvice && (
        <div className="mt-4 animate-fade-in rounded-lg bg-secondary p-4">
          <p className="text-sm font-medium text-secondary-foreground">
            💡 {lastAdvice}
          </p>
        </div>
      )}
    </div>
  );
};

export default MoodSelector;
