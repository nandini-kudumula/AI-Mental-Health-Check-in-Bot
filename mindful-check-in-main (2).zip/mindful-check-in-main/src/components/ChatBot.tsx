import { useState } from "react";
import { Send } from "lucide-react";
import type { MoodEntry } from "@/pages/CheckIn";

interface Message {
  role: "user" | "bot";
  text: string;
}

const botResponses: Record<string, string> = {
  help: "I'm here for you. Remember, it's okay to ask for help. Consider talking to a professional if you're struggling.",
  stress: "Stress can feel overwhelming. Try progressive muscle relaxation: tense each muscle group for 5 seconds, then release.",
  sleep: "Good sleep is vital. Try limiting screens 1 hour before bed, and keep a consistent sleep schedule.",
  exercise: "Even 10 minutes of movement can boost your mood. A short walk in nature works wonders!",
  gratitude: "Practicing gratitude rewires your brain for positivity. Try listing 3 things you're grateful for each day.",
  breathe: "Let's breathe together. Inhale for 4 counts, hold for 4, exhale for 4. Repeat 3 times.",
  default: "I hear you. Remember, every feeling is valid and temporary. What specific aspect would you like to explore?",
};

const getResponse = (input: string): string => {
  const lower = input.toLowerCase();
  for (const [key, resp] of Object.entries(botResponses)) {
    if (key !== "default" && lower.includes(key)) return resp;
  }
  if (lower.includes("sad") || lower.includes("down") || lower.includes("depress")) {
    return "I'm sorry you're feeling this way. You are not alone. Please consider reaching out to a mental health professional if these feelings persist.";
  }
  if (lower.includes("happy") || lower.includes("good") || lower.includes("great")) {
    return "That's wonderful to hear! Keep doing what makes you feel good. 🌟";
  }
  if (lower.includes("anxious") || lower.includes("worried") || lower.includes("nervous")) {
    return "Anxiety can be tough. Try grounding: notice 5 things you see, 4 you hear, 3 you touch, 2 you smell, 1 you taste.";
  }
  return botResponses.default;
};

interface Props {
  entries: MoodEntry[];
}

const ChatBot = ({ entries }: Props) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "bot",
      text: "Hi! I'm your MindCheck companion. Feel free to share anything on your mind, or ask about stress, sleep, breathing, exercise, or gratitude.",
    },
  ]);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", text: input.trim() };
    const botMsg: Message = { role: "bot", text: getResponse(input) };
    setMessages((prev) => [...prev, userMsg, botMsg]);
    setInput("");
  };

  return (
    <div className="flex flex-col rounded-xl border bg-card">
      <h2 className="border-b px-6 py-4 font-display text-xl text-card-foreground">
        Chat with MindCheck
      </h2>
      <div className="flex-1 space-y-3 overflow-y-auto p-4" style={{ maxHeight: 320 }}>
        {messages.map((m, i) => (
          <div
            key={i}
            className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                m.role === "user"
                  ? "gradient-calm text-primary-foreground"
                  : "bg-muted text-foreground"
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2 border-t p-4">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Type a message..."
          className="flex-1 rounded-lg border bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
        <button
          onClick={send}
          className="gradient-calm flex h-10 w-10 items-center justify-center rounded-lg text-primary-foreground transition-transform hover:scale-105"
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default ChatBot;
