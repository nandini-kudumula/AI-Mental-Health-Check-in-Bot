import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import type { MoodEntry } from "@/pages/CheckIn";

interface Props {
  entries: MoodEntry[];
}

const MoodChart = ({ entries }: Props) => {
  const chartData = [...entries]
    .reverse()
    .slice(-14)
    .map((e) => ({
      date: new Date(e.date).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      }),
      score: e.score,
      mood: e.mood,
    }));

  return (
    <div className="space-y-6">
      {/* Chart */}
      <div className="rounded-xl border bg-card p-6">
        <h2 className="mb-4 font-display text-xl text-card-foreground">
          Mood Progress
        </h2>
        {chartData.length < 2 ? (
          <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
            Complete at least 2 check-ins to see your progress chart.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(140 15% 88%)" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 12, fill: "hsl(160 10% 45%)" }}
              />
              <YAxis
                domain={[1, 5]}
                ticks={[1, 2, 3, 4, 5]}
                tick={{ fontSize: 12, fill: "hsl(160 10% 45%)" }}
              />
              <Tooltip
                contentStyle={{
                  background: "hsl(140 20% 97%)",
                  border: "1px solid hsl(140 15% 88%)",
                  borderRadius: 8,
                }}
              />
              <Line
                type="monotone"
                dataKey="score"
                stroke="hsl(155 35% 42%)"
                strokeWidth={3}
                dot={{ fill: "hsl(155 35% 42%)", strokeWidth: 0, r: 5 }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Recent entries */}
      <div className="rounded-xl border bg-card p-6">
        <h2 className="mb-4 font-display text-xl text-card-foreground">
          Recent Check-Ins
        </h2>
        {entries.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No check-ins yet. Share your first mood above!
          </p>
        ) : (
          <div className="space-y-3">
            {entries.slice(0, 5).map((e, i) => (
              <div
                key={i}
                className="flex items-start gap-3 rounded-lg bg-muted/50 p-3"
              >
                <span className="text-xl">
                  {e.mood === "Happy" && "😊"}
                  {e.mood === "Calm" && "😌"}
                  {e.mood === "Neutral" && "😐"}
                  {e.mood === "Anxious" && "😟"}
                  {e.mood === "Sad" && "😢"}
                </span>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">
                      {e.mood}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {new Date(e.date).toLocaleDateString()}
                    </span>
                  </div>
                  {e.note && (
                    <p className="mt-1 text-xs text-muted-foreground">{e.note}</p>
                  )}
                  <p className="mt-1 text-xs text-primary">💡 {e.advice}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MoodChart;
